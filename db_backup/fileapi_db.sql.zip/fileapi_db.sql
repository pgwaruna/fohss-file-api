-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 10, 2021 at 11:21 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.4.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `fileapi_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `api_accounts`
--

CREATE TABLE `api_accounts` (
  `id` int(11) NOT NULL COMMENT 'api table id',
  `user_id` bigint(20) NOT NULL COMMENT 'user id fk to user table (if required later)',
  `system_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Name of the system which api associated with',
  `apitoken` varchar(165) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Token for API access',
  `contact_mob` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Send critical messages',
  `contact_email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Contact Email for notifications',
  `api_expire` date NOT NULL COMMENT 'Expire date of the API',
  `active_status` int(11) NOT NULL DEFAULT 0 COMMENT '1 - Active, 2 - Inactive',
  `created_by` int(11) NOT NULL COMMENT 'Record created by',
  `created_at` datetime NOT NULL COMMENT 'Record created at',
  `modified_by` int(11) NOT NULL COMMENT 'Record Modified by',
  `modified_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp() COMMENT 'Record Modified at'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Pest and Disease API Account details';

--
-- Dumping data for table `api_accounts`
--

INSERT INTO `api_accounts` (`id`, `user_id`, `system_name`, `apitoken`, `contact_mob`, `contact_email`, `api_expire`, `active_status`, `created_by`, `created_at`, `modified_by`, `modified_at`) VALUES
(1, 1, 'Govinena HG READ', 'c835c63fe9671dbcbca1442b22e5abc2ad1eafef10f6ebe4b813e97d9156e0b0', '0714084940', 'waruna.govinena@gmail.com', '2025-12-31', 1, 1, '2020-02-28 00:00:00', 1, '2020-12-20 13:31:50'),
(2, 2, 'Govinena HG FULL', 'a9d90e779ea0fd6671154c516764c43d2509fe8cc4c2d69983ba35dcb09ba420', '0714084940', 'waruna.govinena@gmail.com', '2025-12-31', 1, 1, '2020-02-28 00:00:00', 1, '2021-01-10 10:15:33');

-- --------------------------------------------------------

--
-- Table structure for table `api_activities`
--

CREATE TABLE `api_activities` (
  `id` bigint(20) NOT NULL COMMENT 'Log ID (Auto Increment)',
  `api_id` int(11) DEFAULT NULL COMMENT 'User Index ID',
  `user_name` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `activity` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Funcation user did',
  `url` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Current URL',
  `controller_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'user access controller FK to controller table',
  `action_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'user perform action FK to action table',
  `parameters` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'URL Parameters',
  `status` int(11) NOT NULL COMMENT 'success-1,fail - 0',
  `ip_addr` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'IP Address ',
  `date_time` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'Date and time of the activity',
  `ua_browser` text COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'User''s Web Browser',
  `latitude` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'mobile gps location latitude',
  `longitude` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'mobile gps location longitude',
  `modified_at` timestamp NOT NULL DEFAULT current_timestamp() COMMENT 'updated at'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='API Activity log';

-- --------------------------------------------------------

--
-- Table structure for table `api_settings`
--

CREATE TABLE `api_settings` (
  `id` int(11) NOT NULL COMMENT 'Settings table id',
  `info_api_id` int(11) NOT NULL COMMENT 'FK to infoapi table id',
  `setting_key` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Setting key',
  `setting_value` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Setting value',
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Setting description',
  `show_front` tinyint(2) NOT NULL COMMENT '(0-hide,1-show) Show on the view to user',
  `modified_by` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Record modified by',
  `modified_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp() COMMENT 'Record modified at'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Commen settings of api';

--
-- Dumping data for table `api_settings`
--

INSERT INTO `api_settings` (`id`, `info_api_id`, `setting_key`, `setting_value`, `description`, `show_front`, `modified_by`, `modified_at`) VALUES
(5, 1, 'UPLOAD_FOLDER', 'uploads', 'Media upload folder name', 0, 'SUPERADMIN', '2020-10-12 11:11:04'),
(6, 1, 'UPLOAD_DIR_PERMISSION', '0700', 'Permission for the media upload directory', 0, '', '2020-10-12 11:11:04'),
(7, 1, 'SYSTEM_URL', 'https://s-info.widya.com.au', 'Full System URL', 0, '', '2020-10-12 11:11:04');

-- --------------------------------------------------------

--
-- Table structure for table `api_vs_permission`
--

CREATE TABLE `api_vs_permission` (
  `id` int(11) NOT NULL COMMENT 'Assignment table Id',
  `api_id` int(11) NOT NULL COMMENT 'API account id',
  `permission_key` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'FK to Permission'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `api_vs_permission`
--

INSERT INTO `api_vs_permission` (`id`, `api_id`, `permission_key`) VALUES
(1, 1, 'READ'),
(2, 2, 'READ'),
(3, 2, 'WRITE'),
(4, 2, 'DELETE');

-- --------------------------------------------------------

--
-- Table structure for table `channels`
--

CREATE TABLE `channels` (
  `id` int(11) NOT NULL COMMENT 'Channel id',
  `channel_name` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Name of the channel'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `channels`
--

INSERT INTO `channels` (`id`, `channel_name`) VALUES
(4, 'Govinena Farmer App'),
(5, 'Govinena HG App');

-- --------------------------------------------------------

--
-- Table structure for table `files`
--

CREATE TABLE `files` (
  `id` bigint(11) NOT NULL COMMENT 'File id',
  `file_name` varchar(200) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'User uploaded File name',
  `file_path` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'Relative path of file',
  `access_token` text NOT NULL COMMENT 'File access tokens',
  `filetype_id` int(11) NOT NULL COMMENT 'FK to file type table',
  `channel_id` int(11) NOT NULL COMMENT 'FK to channels',
  `active_status` int(11) NOT NULL COMMENT 'File active status (0-Inactive, 1-Active)',
  `delete_status` int(11) NOT NULL COMMENT 'File delete status (0-Inactive, 1-Active)'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `files`
--

INSERT INTO `files` (`id`, `file_name`, `file_path`, `access_token`, `filetype_id`, `channel_id`, `active_status`, `delete_status`) VALUES
(1, 'test_file.jpg', '/govinenahg/images/', 'gdfdgDFDfdfd45454#fd45', 2, 4, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `file_types`
--

CREATE TABLE `file_types` (
  `id` int(11) NOT NULL COMMENT 'File type id',
  `mime_type` varchar(255) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL COMMENT 'File MIME type',
  `type_image` varchar(255) NOT NULL COMMENT 'File image'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `file_types`
--

INSERT INTO `file_types` (`id`, `mime_type`, `type_image`) VALUES
(1, 'application/msword', ''),
(2, 'image/jpeg', ''),
(3, 'application/pdf', '');

-- --------------------------------------------------------

--
-- Table structure for table `permission`
--

CREATE TABLE `permission` (
  `id` int(11) NOT NULL,
  `permission_key` varchar(50) COLLATE utf8_unicode_ci NOT NULL COMMENT 'File permissions'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `permission`
--

INSERT INTO `permission` (`id`, `permission_key`) VALUES
(6, 'DELETE'),
(4, 'READ'),
(5, 'WRITE');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `api_accounts`
--
ALTER TABLE `api_accounts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `token` (`apitoken`),
  ADD UNIQUE KEY `system_name` (`system_name`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `api_activities`
--
ALTER TABLE `api_activities`
  ADD PRIMARY KEY (`id`),
  ADD KEY `api_id` (`api_id`);

--
-- Indexes for table `api_settings`
--
ALTER TABLE `api_settings`
  ADD PRIMARY KEY (`id`),
  ADD KEY `info_api_id` (`info_api_id`);

--
-- Indexes for table `api_vs_permission`
--
ALTER TABLE `api_vs_permission`
  ADD PRIMARY KEY (`id`),
  ADD KEY `api_id` (`api_id`),
  ADD KEY `permission_id` (`permission_key`);

--
-- Indexes for table `channels`
--
ALTER TABLE `channels`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `channel_name` (`channel_name`);

--
-- Indexes for table `files`
--
ALTER TABLE `files`
  ADD PRIMARY KEY (`id`),
  ADD KEY `filetype_id` (`filetype_id`),
  ADD KEY `channel_id` (`channel_id`);

--
-- Indexes for table `file_types`
--
ALTER TABLE `file_types`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `permission`
--
ALTER TABLE `permission`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `permission_key` (`permission_key`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `api_accounts`
--
ALTER TABLE `api_accounts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'api table id', AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `api_activities`
--
ALTER TABLE `api_activities`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'Log ID (Auto Increment)';

--
-- AUTO_INCREMENT for table `api_settings`
--
ALTER TABLE `api_settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Settings table id', AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `api_vs_permission`
--
ALTER TABLE `api_vs_permission`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Assignment table Id', AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `channels`
--
ALTER TABLE `channels`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Channel id', AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `files`
--
ALTER TABLE `files`
  MODIFY `id` bigint(11) NOT NULL AUTO_INCREMENT COMMENT 'File id', AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `file_types`
--
ALTER TABLE `file_types`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'File type id', AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `permission`
--
ALTER TABLE `permission`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `api_settings`
--
ALTER TABLE `api_settings`
  ADD CONSTRAINT `api_settings_ibfk_1` FOREIGN KEY (`info_api_id`) REFERENCES `api_accounts` (`id`);

--
-- Constraints for table `api_vs_permission`
--
ALTER TABLE `api_vs_permission`
  ADD CONSTRAINT `api_vs_permission_ibfk_1` FOREIGN KEY (`api_id`) REFERENCES `api_accounts` (`id`),
  ADD CONSTRAINT `api_vs_permission_ibfk_2` FOREIGN KEY (`permission_key`) REFERENCES `permission` (`permission_key`);

--
-- Constraints for table `files`
--
ALTER TABLE `files`
  ADD CONSTRAINT `files_ibfk_3` FOREIGN KEY (`filetype_id`) REFERENCES `file_types` (`id`),
  ADD CONSTRAINT `files_ibfk_4` FOREIGN KEY (`channel_id`) REFERENCES `channels` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
